package com.raqamsaree.app;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.TextView;

public class FloatingService extends Service {
    WindowManager wm;
    View bubble;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(10, notification());
        showBubble();
    }

    void showBubble() {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        TextView v = new TextView(this);
        v.setText("⌾");
        v.setTextColor(Color.WHITE);
        v.setTextSize(24);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(Color.rgb(35,35,35));
        bubble = v;

        int type = Build.VERSION.SDK_INT >= 26 ?
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
            WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            64,64,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP|Gravity.START; lp.x=30; lp.y=250;

        v.setOnClickListener(x -> activateSelectionMode());
        wm.addView(v, lp);
    }

    void activateSelectionMode() {
        // المرحلة التالية: MediaProjection + OCR.
    }

    Notification notification() {
        PendingIntent pi = PendingIntent.getActivity(this,0,
            new Intent(this,MainActivity.class),
            PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,"raqam")
            .setContentTitle("رقم سريع").setContentText("مفعل")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentIntent(pi).setOngoing(true).build();
    }

    void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                "raqam","رقم سريع",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    @Override public void onDestroy() {
        if (wm != null && bubble != null) try { wm.removeView(bubble); } catch(Exception ignored){}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
