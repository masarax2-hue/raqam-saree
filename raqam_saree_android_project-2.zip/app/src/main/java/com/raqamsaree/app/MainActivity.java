package com.raqamsaree.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    TextView status;
    boolean active = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.BLACK);
        root.setPadding(24, 55, 24, 24);

        TextView title = new TextView(this);
        title.setText("رقم سريع");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, 60));

        status = new TextView(this);
        status.setText("غير مفعل");
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, 50));

        Button main = new Button(this);
        main.setText("تشغيل");
        main.setTextSize(20);
        main.setOnClickListener(v -> toggle());
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(180, 180);
        mp.gravity = Gravity.CENTER;
        mp.topMargin = 100;
        root.addView(main, mp);

        TextView menu = new TextView(this);
        menu.setText("⋮");
        menu.setTextColor(Color.WHITE);
        menu.setTextSize(32);
        menu.setGravity(Gravity.CENTER);
        menu.setOnClickListener(v -> showOptions());
        LinearLayout.LayoutParams menuP = new LinearLayout.LayoutParams(70,70);
        menuP.gravity = Gravity.TOP | Gravity.RIGHT;
        root.addView(menu, menuP);

        setContentView(root);
    }

    void toggle() {
        if (!active) {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
                return;
            }
            startService(new Intent(this, FloatingService.class));
            active = true;
            status.setText("مفعل");
        } else {
            stopService(new Intent(this, FloatingService.class));
            active = false;
            status.setText("غير مفعل");
        }
    }

    void showOptions() {
        new AlertDialog.Builder(this)
            .setItems(new String[]{"🌙 السمة السوداء", "📋 نسخ الكلام", "الخيار الثالث — قريبًا"},
                (d,w) -> {})
            .show();
    }
}
